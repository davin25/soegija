<?php
include_once("config.php");
// Display selected user data based on id
// Getting id from url
$id = $_GET['id'];
 
// Fetech user data based on id
$result = mysqli_query($mysqli, "SELECT * FROM datagame WHERE id=$id");
// Check if form is submitted for user update, then redirect to homepage after update
    $status=0;
    // update user data
    $result = mysqli_query($mysqli, "UPDATE datagame SET status=$status WHERE id=$id");
    
    // Redirect to homepage to display updated user in list
    header("Location: index.php");
?>